module.exports = {
  mode: 'development',
  devtool: 'none',
  entry: './main.js',
  output: {
    filename: 'bundle.js',
  }
}
